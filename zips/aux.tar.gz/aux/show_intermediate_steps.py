from collections import defaultdict

def detectedcomms(plist):
	for p in plist:
		louvain_p = defaultdict(list)
		for l in p.keys():
			louvain_p[p[l]].append(l)
		print louvain_p

def printgraph(ngraph): 
	print(type(ngraph), ngraph)
	print "Printing graph: "
	print(list(ngraph.nodes()))
	print(list(ngraph.edges(data = True)))
	print "Done printing graphs"